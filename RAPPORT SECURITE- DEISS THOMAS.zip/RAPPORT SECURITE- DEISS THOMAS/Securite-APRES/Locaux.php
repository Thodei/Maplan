<?php require 'secure_admin.php';?>
<!doctype html>
<html lang="fr">

<head>
  <title>Administration</title>
</head>

</body>
<?php require './scripts_bootstrap.php'; ?>
</body>
</html>
