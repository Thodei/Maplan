                          <div class="container col" id="MainConnexion">
                            <form name='f' id='f' action="#" method="post">

                              <input type="text"      name="user"   class="form-control" placeholder="Nom d'utilisateur" />
                              <input type="password"  name="mdp"    class="form-control" placeholder="Mot de passe" />
                              <input type="password"  name="mdpc"   class="form-control" placeholder="Confirmation" />
                              <input type='submit'    name="submit" class="btn btn-sm btn-primary btn-block" role="button">
                            </form>
                          </div>